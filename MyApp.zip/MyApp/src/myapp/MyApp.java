package myapp;

import java.awt.Font;
import javax.swing.UIManager;

public class MyApp {

    public static void main(String[] args) {
        Font fonts = new Font("Microsoft sans serif", Font.PLAIN, 16);
        UIManager.put("OptionPane.messageFont", fonts);

        Login loginFrame = new Login();
        loginFrame.setVisible(true);
        loginFrame.pack();
        loginFrame.setLocationRelativeTo(null);
    }
}
