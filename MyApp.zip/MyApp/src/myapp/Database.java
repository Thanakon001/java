/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package myapp;

import java.sql.*;

/**
 *
 * @author Thanakon Sanesri
 */
public class Database {

    private Connection conn;
    private Statement stmt;
    private ResultSet result;

    private final String url = "jdbc:mariadb://localhost:3306/myapp";
    private final String userdb = "root";
    private final String passdb = "";
    
    private int row;

    public Database() {
        try {
            conn = DriverManager.getConnection(url, userdb, passdb);
            System.out.println("connecnted sucessfully");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public Connection getConnection() {
        try {
            conn = DriverManager.getConnection(url, userdb, passdb);
            System.out.println("connecnted sucessfully");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return conn;
    }

    public int commit(String sql) {
        try {
            stmt = conn.createStatement();
            row = stmt.executeUpdate(sql);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        } finally {
            this.disconnect();
        }
        return row;
    }

    public ResultSet getQuery(String sql) {
        try {
            stmt = conn.createStatement();
            result = stmt.executeQuery(sql);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        } finally {
            this.disconnect();
        }
        return result;
    }

    public void disconnect() {
        try {
            conn.close();
            stmt.close();
            result.close();
            System.out.println("close database sucessfully");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
