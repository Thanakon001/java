/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package myapp;

import java.awt.Component;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JTable;

/**
 *
 * @author Thanakon Sanesri
 */
public class ButtonEdit extends DefaultCellEditor {
    
    private String label;
    private JButton button;
    private JTable table;
    
    public ButtonEdit(JCheckBox check, JTable table, String label) {
        super(check);
        this.button = new JButton();
        this.button.setOpaque(true);
        this.label = label;
        this.table = table;
//        เพิ่ม Event cilck ให้ปุ่ม
        button.addActionListener(e -> {
            int row = table.getSelectedRow();
            

//            ดึงค่าจากตารางที่กด
            String m_user = (String) table.getValueAt(row, 0);
            String m_pass = (String) table.getValueAt(row, 1);
            String m_name = (String) table.getValueAt(row, 2);
            String m_phone = (String) table.getValueAt(row, 3);

//            หากค่ากดคลิกที่ TableEditCell ตรงกับ if ก็จะทำงาน
            if (label.equals("edit")) {
                ModalEdit modalEdit = new ModalEdit();
                modalEdit.setData(m_user, m_pass, m_name, m_phone);
                modalEdit.setVisible(true);
                modalEdit.setLocationRelativeTo(null);
                
            } else if (label.equals("delete")) {
                System.out.println("row delete array  :" + row);
            }
        });
    }
    
    @Override
    public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
        this.button.setText(label);
        return button;
    }
}
